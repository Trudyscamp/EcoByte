### Eu vi: Um aplicativo de turismo que ainda está por vir. 
### Protótipo em andamento construído em React-Native.
